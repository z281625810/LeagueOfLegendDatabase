use LoLDb;

Insert into ChampType Values
(0, 'Fighter'),
(1, 'Mage'),
(2, 'Assassin'),
(3, 'Tank'),
(4, 'Support'),
(5, 'Marksman')