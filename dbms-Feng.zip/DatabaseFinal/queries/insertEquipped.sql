use LoLDb;

insert into Equipped values
('Kalista','The Black Spear');