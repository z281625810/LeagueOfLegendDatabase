use LoLDb;

Insert into EquipType Values
(0, 'Jungle'),
(1, 'Lane'),
(2, 'Consumable'),
(3, 'Gold Income'),
(4, 'Vision and Trinkets'),
(5, 'Armor'),
(6, 'Health'),
(7, 'Health Regen'),
(8, 'Magic Resist'),
(9, 'Attack Speed'),
(10,'Critical Strike'),
(11,'Damage'),
(12,'Life Steal'),
(13,'Cooldown Reduction'),
(14,'Mana'),
(15,'Mana Regen'),
(16,'Ability Power'),
(17,'Boots'),
(18,'Other Movement');